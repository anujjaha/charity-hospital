<?php namespace App\Models\Surgery\Traits\Relationship;

trait Relationship
{
}