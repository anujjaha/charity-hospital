<?php namespace App\Models\Cart\Traits\Attribute;

/**
 * Trait Attribute
 *
 * @author Anuj Jaha
 */

use File;
use App\Repositories\Category\EloquentCategoryRepository;

trait Attribute
{
}