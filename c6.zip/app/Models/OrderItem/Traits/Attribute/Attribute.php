<?php namespace App\Models\OrderItem\Traits\Attribute;

/**
 * Trait Attribute
 *
 * @author Anuj Jaha
 */

trait Attribute
{
	
}