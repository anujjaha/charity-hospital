<?php namespace App\Models\Patient\Traits\Relationship;

trait Relationship
{
}