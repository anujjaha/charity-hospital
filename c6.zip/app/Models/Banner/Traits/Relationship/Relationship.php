<?php namespace App\Models\Banner\Traits\Relationship;


trait Relationship
{
}