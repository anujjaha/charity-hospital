<?php namespace App\Models\Schedule\Traits\Relationship;

trait Relationship
{
}