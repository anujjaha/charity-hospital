<?php namespace App\Models\Settings\Traits\Relationship;

trait Relationship
{
}